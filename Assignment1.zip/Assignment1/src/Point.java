package src;

class Point {

    private double x, y;

    public Point() {
        this.x = 0;
        this.y = 0;
    }

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public double getDistanceP(Point p) {
        // d=√((x2 – x1)² + (y2 – y1)²).
        double d = Math.sqrt((p.getX() - this.getX()) * (p.getX() - this.getX())
                + (p.getY() - this.getY()) * (p.getY() - this.getY()));
return d;
    }
    // Point getCenter() {return this;}

}