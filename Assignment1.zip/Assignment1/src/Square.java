package src;

public class Square extends shape {

    // consructors
    public Square() {
        Center = new Point(0, 0);
        side = 0;

    }

    public Square(double x, double y, double r) {
        Center = new Point(x, y);
        side = r;
    }

    /////////////////////////////
    @Override
    public double getDistance(Point p) {
        Point p1, p2, p3, p4;
        p1 = new Point(Center.getX() - (side / 2), Center.getY() + (side / 2));
        p2 = new Point(Center.getX() + (side / 2), Center.getY() + (side / 2));
        p3 = new Point(Center.getX() + (side / 2), Center.getY() - (side / 2));
        p4 = new Point(Center.getX() - (side / 2), Center.getY() - (side / 2));

        //is inside
       if( p.getX() >=p1.getX() && p.getX() <=p2.getX() && p.getY()<=p1.getY() &&  p.getY() >=p3.getY()      )return -1;


        // point is closer to line or points
        if ((p.getX() < p1.getX() && p.getY() > p1.getY())) {
            return (Math.sqrt((p.getX() - p1.getX()) * (p.getX() - p1.getX())
                    + (p.getY() - p1.getY()) * (p.getY() - p1.getY())));
        }
        if ((p.getX() > p2.getX() && p.getY() > p2.getY())) {
            return (Math.sqrt((p.getX() - p2.getX()) * (p.getX() - p2.getX())
                    + (p.getY() - p2.getY()) * (p.getY() - p2.getY())));
        }
        if ((p.getX() > p3.getX() && p.getY() < p3.getY())) {
            return (Math.sqrt((p.getX() - p3.getX()) * (p.getX() - p3.getX())
                    + (p.getY() - p3.getY()) * (p.getY() - p3.getY())));
        }
        if ((p.getX() < p4.getX() && p.getY() < p4.getY())) {
            return (Math.sqrt((p.getX() - p4.getX()) * (p.getX() - p4.getX())
                    + (p.getY() - p4.getY()) * (p.getY() - p4.getY())));
        }

        /////////////

        if (p.getY() > (Center.getY() + side / 2)) {
            return distanceBetweenPandLine(p1, p2, p);
        }

        else if (p.getY() < (Center.getY() - side / 2)) {
            return distanceBetweenPandLine(p3, p4, p);
        }

        else if (p.getX() > (Center.getX() + side / 2)) {
            return distanceBetweenPandLine(p2, p3, p);
        }

        else if (p.getX() < (Center.getX() - side / 2)) {
            return distanceBetweenPandLine(p4, p1, p);
        }

        //

        return 0.3;
    }

}
