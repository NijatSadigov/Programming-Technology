package src;

public class Hexagon extends shape {
    public Hexagon() {
        Center = new Point(0, 0);
        setSide(0);

    }

    public Hexagon(double x, double y, double r) {
        Center = new Point(x, y);
        setSide(r);
    }

    // is inside
    public boolean IsInsideHexagon(Point p) {
        double d = side;
        double dx = Math.abs(p.getX() - this.getCenter().getX()) / d;
        double dy = Math.abs(p.getY() - this.getCenter().getY()) / d;
        double a = 0.25 * Math.sqrt(3.0);
        return (dy <= a) && (a * dx + 0.25 * dy <= 0.5 * a);
    }

    // abstracts
    @Override
    public double getDistance(Point p) {

        Point p1, p2, p3, p4, p5, p6;

        p1 = new Point(Center.getX() - (side / 2), Center.getY() + (side / 2));
        p2 = new Point(Center.getX() + (side / 2), Center.getY() + (side / 2));
        p3 = new Point(Center.getX() + side, Center.getY());
        p4 = new Point(Center.getX() + (side / 2), Center.getY() - (side / 2));
        p5 = new Point(Center.getX() - (side / 2), Center.getY() - (side / 2));
        p6 = new Point(Center.getX() - side, Center.getY());

        // is inside

        if (IsInsideHexagon(p))
            return -1;

        // check side 1 -- up and down p1-p2 p4-p5

        if (p1.getX() <= p.getX() && p2.getX() >= p.getX() && p2.getY() <= p.getY()) {
            return p.getY() - p1.getY();
        }

        else if (p1.getX() <= p.getX() && p2.getX() >= p.getX() && p4.getY() >= p.getY()) {
            return p4.getY() - p.getY();
        }

        // m= tan(150) p2-p3 and p5-p6
        double m = Math.tan(150);

        // upperright
        // double x,y;
        if (p2.getX() < p.getX() && (-m * p.getX() + p.getY()) >= (-m * p2.getX() + p2.getY())
                && (-m * p.getX() + p.getY()) <= (-m * p3.getX() + p3.getY())) {
            return distanceBetweenPandLine(p2, p3, p);

        } else if (p2.getX() < p.getX() && (-m * p.getX() + p.getY()) <= (-m * p2.getX() + p2.getY())
                && (-m * p.getX() + p.getY()) >= (-m * p3.getX() + p3.getY())) {
            return distanceBetweenPandLine(p2, p3, p);

        }

        // down left

        if (p5.getX() > p.getX() && (-m * p.getX() + p.getY()) >= (-m * p5.getX() + p5.getY())
                && (-m * p.getX() + p.getY()) <= (-m * p6.getX() + p6.getY())) {
            return distanceBetweenPandLine(p5, p6, p);

        } else if (p5.getX() > p.getX() && (-m * p.getX() + p.getY()) <= (-m * p5.getX() + p5.getY())
                && (-m * p.getX() + p.getY()) >= (-m * p6.getX() + p6.getY())) {
            return distanceBetweenPandLine(p5, p6, p);

        }

        // m= tan(30) p3-p4 and p6-p1

        m = Math.tan(30);

        // upper left
        if (p1.getX() > p.getX() && (-m * p.getX() + p.getY()) >= (-m * p3.getX() + p3.getY())
                && (-m * p.getX() + p.getY()) <= (-m * p4.getX() + p4.getY())) {
            return distanceBetweenPandLine(p3, p4, p);

        } else if (p1.getX() > p.getX() && (-m * p.getX() + p.getY()) <= (-m * p3.getX() + p3.getY())
                && (-m * p.getX() + p.getY()) >= (-m * p4.getX() + p4.getY())) {
            return distanceBetweenPandLine(p3, p4, p);

        }

        // down right
        if (p4.getX() < p.getX() && (-m * p.getX() + p.getY()) >= (-m * p6.getX() + p6.getY())
                && (-m * p.getX() + p.getY()) <= (-m * p1.getX() + p1.getY())) {
            return distanceBetweenPandLine(p3, p4, p);

        } else if (p4.getX() < p.getX() && (-m * p.getX() + p.getY()) <= (-m * p6.getX() + p6.getY())
                && (-m * p.getX() + p.getY()) >= (-m * p1.getX() + p1.getY())) {
            return distanceBetweenPandLine(p3, p4, p);

        }

        // in other caes
        double d1, d2, d3, d4, d5, d6;
        d1 = p.getDistanceP(p1);
        d2 = p.getDistanceP(p2);
        d3 = p.getDistanceP(p3);
        d4 = p.getDistanceP(p4);
        d5 = p.getDistanceP(p5);
        d6 = p.getDistanceP(p6);

        double[] myNum = { d1, d2, d3, d4, d5, d6 };
        double min = d1;
        for (int i = 1; i < 6; i++) {
            if (myNum[i] < min)
                min = myNum[i];
        }

        return min;

    }
}
