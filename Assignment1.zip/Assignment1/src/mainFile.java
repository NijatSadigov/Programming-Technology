package src;

import java.io.FileNotFoundException;

//import java.util.ArrayList; // import the ArrayList class

//import src.Circle;

public class mainFile {

    /**
     *
     */

    public static void main(String[] args) {
        Database myDatabase = new Database();

        try {
            myDatabase.read("src/input7.txt");
        } catch (FileNotFoundException ex) {
            System.out.println("File not found!");
            System.exit(-1);
        } catch (InvalidInputException ex) {
            System.out.println("inv input");
            System.exit(-1);
        }

        // catch (InvalidInputException ex) {
        // System.out.println("Invalid input!");
        // System.exit(-1);
        // }
        Point p = new Point(25, 25);
        System.out.println("Closest Shapes: " + myDatabase.Run(p));
        
        
        // myDatabase.Run(p);

        // myDatabase.PrintAll();

    }

}
