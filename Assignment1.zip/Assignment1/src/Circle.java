package src;

import java.lang.Math;


//import src.Point;

public class Circle extends shape {

    // consturctors
    public Circle() {
        Center = new Point(0, 0);
        setSide(0);

    }

    public Circle(double x, double y, double r) {
        Center = new Point(x, y);
        setSide(r);
    }

    // abstracts
    @Override
    public double getDistance(Point p) {
        return (Math.sqrt((p.getX() - this.Center.getX()) * (p.getX() - this.Center.getX())
                + (p.getY() - this.Center.getY()) * (p.getY() - this.Center.getY()))) - getSide();

        // return 0.3;
    }

    // Print for mostly test

}
