package src;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileInputStream;

public class Database {
    private final ArrayList<shape> Shapes;
    int numberOfshapes;

    public Database() {
        Shapes = new ArrayList<>();
    }

    public void read(String fileName) throws FileNotFoundException, InvalidInputException {

        FileInputStream fis = new FileInputStream(fileName);
        Scanner sc = new Scanner(fis); // file to be scanned
        // returns true if there is another line to read
        if (sc.hasNextLine()) {
            String word = sc.nextLine();
            numberOfshapes = Integer.parseInt(word);

        }

        int lineNumber = 0;
        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] words = line.split(" ");
            ;

            shape cShape;

            if (words[0].equals("c")) {
                double x, y, r;
                x = Double.parseDouble(words[1]);
                y = Double.parseDouble(words[2]);
                r = Double.parseDouble(words[3]);
                cShape = new Circle(x, y, r);
                Shapes.add(cShape);

            } else if (words[0].equals("s")) {
                double x, y, s;
                x = Double.parseDouble(words[1]);
                y = Double.parseDouble(words[2]);
                s = Double.parseDouble(words[3]);
                cShape = new Square(x, y, s);
                Shapes.add(cShape);

            } else if (words[0].equals("t")) {
                double x, y, s;
                x = Double.parseDouble(words[1]);
                y = Double.parseDouble(words[2]);
                s = Double.parseDouble(words[3]);
                cShape = new Triangle(x, y, s);
                Shapes.add(cShape);

            } else if (words[0].equals("h")) {
                double x, y, s;
                x = Double.parseDouble(words[1]);
                y = Double.parseDouble(words[2]);
                s = Double.parseDouble(words[3]);
                cShape = new Hexagon(x, y, s);
                Shapes.add(cShape);

            } else
                throw new InvalidInputException();

            // System.out.println(sc.nextLine()); // returns the line that was skipped
            lineNumber++;
        }

        sc.close(); // closes the scanner

        if (lineNumber != numberOfshapes) {
            throw new InvalidInputException();
        }

    }

    public String Run(Point p) {
        double min;
        String minimumShape;
        ArrayList<String> negatives = new ArrayList<>();
        ;

        minimumShape = ((Object) Shapes.get(0)).getClass().getSimpleName();
        min = Shapes.get(0).getDistance(p);

        for (shape c : Shapes) {
            if (c.getDistance(p) <= 0) {
                negatives.add(((Object) c).getClass().getSimpleName());
            } else if (c.getDistance(p) < min) {
                min = c.getDistance(p);
                minimumShape = ((Object) c).getClass().getSimpleName();
            }

        }

        if (negatives.size() > 0) {
            minimumShape = "";
            for (String s : negatives) {
                minimumShape += s + " ";
            }
        }

        return minimumShape;

    }

    public void PrintAll() {
        for (shape c : Shapes) {
            c.PrintC();
            System.out.println();

        }

    }

    public void clear() {
        Shapes.clear();
    }
}
