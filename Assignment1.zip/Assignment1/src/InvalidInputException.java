package src;

class InvalidInputException extends Exception {

    public InvalidInputException() {
    }

}
