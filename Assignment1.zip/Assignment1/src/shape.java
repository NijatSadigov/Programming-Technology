package src;

//import src.Point;

public abstract class shape {
    protected Point Center;
    protected double side;

    // getters
    public Point getCenter() {
        return Center;
    }

    public double getSide() {
        return side;
    }

    // setters
    protected void setCenter(double x, double y) {
        Center = new Point(x, y);
    }

    public void setSide(double r) {
        this.side = r;
    }

    // abstract methods
    public abstract double getDistance(Point p);

    // methods for mostly testing
    public void PrintC() {
        System.out.print("X: " + this.Center.getX() + "  Y: " + this.Center.getY() + " Radius: " + this.getSide());
    }

    // helper methods

    protected double distanceBetweenPandLine(Point x, Point y, Point z) {

        double a = (Math
                .abs((y.getX() - x.getX()) * (x.getY() - z.getY()) - (y.getY() - x.getY()) * (x.getX() - z.getX())));

        double b = Math
                .sqrt((x.getX() - y.getX()) * (x.getX() - y.getX()) + (x.getY() - y.getY()) * (x.getY() - y.getY()));

        return a / b;
    }

}
