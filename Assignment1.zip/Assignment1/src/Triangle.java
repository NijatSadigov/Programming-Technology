package src;

public class Triangle extends shape {

    public Triangle() {
        Center = new Point(0, 0);
        setSide(0);

    }

    public Triangle(double x, double y, double r) {
        Center = new Point(x, y);
        setSide(r);
    }

    // abstracts
    @Override
    public double getDistance(Point p) {
        // return (Math.sqrt((p.getX() - this.Center.getX()) * (p.getX() -
        // this.Center.getX())
        // + (p.getY() - this.Center.getY()) * (p.getY() - this.Center.getY()))) -
        // getSide();

        Point a, b, c;

        // left
        a = new Point(this.getCenter().getX() - this.getSide() / 2,
                this.getCenter().getY() - this.getSide() * Math.sqrt(3) / 6);

        // right
        b = new Point(this.getCenter().getX() + this.getSide() / 2,
                this.getCenter().getY() - this.getSide() * Math.sqrt(3) / 6);
        // mid
        c = new Point(this.getCenter().getX(), this.getCenter().getY() + this.getSide() / Math.sqrt(3));

        ////////////////////

        // is inside
        if ((distanceBetweenPandLine(c, a, p) + distanceBetweenPandLine(a, b, p)
                + distanceBetweenPandLine(b, c, p)) == (this.getSide() * Math.sqrt(3) / 2))
            return -1;

        // if down
        if (p.getY() < a.getY() && p.getX() >= a.getX() && p.getX() <= b.getX()) {
            return a.getY() - p.getY();
        } else if (p.getY() < a.getY()) {
            double d1, d2;
            d1 = a.getDistanceP(p);
            d2 = b.getDistanceP(p);
            if (d1 < d2)
                return d1;
            else
                return d2;

        }

        // if leftside
        double m = Math.tan(30);

        if ((-m * a.getX() + a.getY()) <= (-m * p.getX() + p.getY())
                && (-m * c.getX() + c.getY()) >= (-m * p.getX() + p.getY())) {
            return distanceBetweenPandLine(a, c, p);

        } else if ((-m * a.getX() + a.getY()) >= (-m * p.getX() + p.getY())
                && (-m * c.getX() + c.getY()) <= (-m * p.getX() + p.getY())) {
            return distanceBetweenPandLine(c, a, p);

        }

        // if rightSide
        m = Math.tan(150);

        if ((-m * a.getX() + a.getY()) <= (-m * p.getX() + p.getY())
                && (-m * c.getX() + c.getY()) >= (-m * p.getX() + p.getY()) && p.getX() <= c.getX()) {
            return distanceBetweenPandLine(a, c, p);

        } else if ((-m * a.getX() + a.getY()) >= (-m * p.getX() + p.getY())
                && (-m * c.getX() + c.getY()) <= (-m * p.getX() + p.getY()) && p.getX() <= c.getX()) {
            return distanceBetweenPandLine(c, a, p);

        }

        // in other cases

        double d1, d2, d3;
        d1 = a.getDistanceP(p);
        d2 = b.getDistanceP(p);
        d3 = c.getDistanceP(p);

        if (d1 < d2 && d1 < d3)
            return d1;
        else if (d3 < d2 && d3 < d1)
            return d3;
        else
            return d2;

    }
}
